"""Helper module for calling numba-compiled WASM functions from python"""

from . import util, example_module
