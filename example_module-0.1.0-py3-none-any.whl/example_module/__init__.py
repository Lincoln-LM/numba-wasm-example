"""Example pyodide-compatible module with numba compiled functions"""
from .example import *
